// https://www.typescriptlang.org/play/?q=98
// TypeScript has some fun special cases for literals in
// source code.

// In part, a lot of the support is covered in type widening
// and narrowing ( example:type-widening-and-narrowing ) and it's
// worth covering that first.

// A literal is a more concrete subtype of a collective type.
// What this means is that "Hello World" is a string, but a
// string is not "Hello World" inside the type system.

const helloWorld = 'Hello World';
const HI_WORLD = 'Hi World';
// `hiWorld` is never reassigned
// Use `const` insteaddeno-lint(prefer-const)
let hiWorld = 'Hi World'; // this is a string because it is let
hiWorld = 'Hello World';
// const hiWorld = "Hi World"; // this is a string because it is let

// This function takes all strings
// 'allowsAnyString', which lacks return-type annotation, implicitly has an 'any' return type.deno-ts(7010)
// declare function allowsAnyString(arg: string);
declare function allowsAnyString(arg: string): void;
allowsAnyString(helloWorld);
allowsAnyString(hiWorld);

// This function only accepts the string literal "Hello World"
// declare function allowsOnlyHello(arg: "Hello World");
declare function allowsOnlyHello(arg: 'Hello World'): void;
allowsOnlyHello(helloWorld);
// Argument of type '"Hi World"' is not assignable to parameter of type '"Hello World"'.deno-ts(2345)
allowsOnlyHello(HI_WORLD);
// Argument of type 'string' is not assignable to parameter of type '"Hello World"'.deno-ts(2345)
allowsOnlyHello(hiWorld);。

// This lets you declare APIs which use unions to say it
// only accepts a particular literal:

// declare function allowsFirstFiveNumbers(arg: 1 | 2 | 3 | 4 | 5);
declare function allowsFirstFiveNumbers(arg: 1 | 2 | 3 | 4 | 5): void;
allowsFirstFiveNumbers(1);
// error: Argument of type '10' is not assignable to parameter of type '2 | 1 | 3 | 4 | 5'.deno-ts(2345)
allowsFirstFiveNumbers(10);

// Argument of type 'number' is not assignable to parameter of type '2 | 1 | 3 | 4 | 5'.deno-ts(2345)
let potentiallyAnyNumber = 3;
allowsFirstFiveNumbers(potentiallyAnyNumber);
allowsFirstFiveNumbers(potentiallyAnyNumber as 1 | 2 | 3 | 4 | 5);
potentiallyAnyNumber = 5;
allowsFirstFiveNumbers(potentiallyAnyNumber);
allowsFirstFiveNumbers(potentiallyAnyNumber as 1 | 2 | 3 | 4 | 5);

const potentiallyAnyNumberConst = 3;
allowsFirstFiveNumbers(potentiallyAnyNumberConst);

// At first glance, this rule isn't applied to complex objects.

const myUser = {
	name: 'Sabrina',
};

// See how it transforms `name: "Sabrina"` to `name: string`
// even though it is defined as a constant. This is because
// the name can still change any time:

myUser.name = 'Cynthia';

// Because myUser's name property can change, TypeScript
// cannot use the literal version in the type system. There
// is a feature which will allow you to do this however.

const myUnchangingUser = {
	name: 'Fatma',
} as const;

// When "as const" is applied to the object, then it becomes
// a object literal which doesn't change instead of a
// mutable object which can.
// [Error]Cannot assign to 'name' because it is a read-only property.deno-ts(2540)
// myUnchangingUser.name = "Raîssa";

// "as const" is a great tool for fixtured data, and places
// where you treat code as literals inline. "as const" also
// works with arrays:

const exampleUsers = [{ name: 'Brian' }, { name: 'Fahrooq' }] as const;
